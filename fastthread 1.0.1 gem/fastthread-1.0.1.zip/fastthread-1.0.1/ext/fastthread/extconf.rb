require 'mkmf'

create_makefile('fastthread')
